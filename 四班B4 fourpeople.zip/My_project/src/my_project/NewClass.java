package my_project;
import java.sql.*;
public class NewClass 
 {
    static private Connection connection;
    public static Connection getConnection() throws Exception
    {
    if(connection==null)
    {
    Class.forName("com.mysql.jdbc.Driver");
    connection=DriverManager.getConnection("jdbc:mysql://localhost:3306/student", "root", "1234");
    }
    return connection;
    }
}
